<html>
   <head>
      <?php
         INCLUDE "header.php";

         //Consulta e filtra clientes conforme id_vendedor
         $clientes = mysqli_query($connection, "SELECT CODIGO, NOME FROM clientes, sec_users WHERE VENDEDOR = $login_cookie GROUP BY CODIGO");

         if(isset($_POST["incluir"])) {
         $idpedido = $_POST["id_Pedido"];
			$idvendedor = $_POST["idusuario"];
			$status = $_POST["select-status"];
			$datapedido = $_POST["datapedido"];
         $cliente = $_POST["select-cliente"];
         $tipo = $_POST["select-tipo"];

         $sql = "INSERT INTO pedidos (NRO_PEDIDO, VENDEDOR, STATUS, DATA, CLIENTE, TIPO)
                  values('$idpedido', '$idvendedor','$status', '$datapedido', 'select-cliente', 'select-tipo')";
                  mysqli_query($connection, $sql);
         }


         if(isset($_POST["excluir"])) {
         $idpedido = $_POST["id_Pedido"];
         $idvendedor = $_POST["idusuario"];
         $status = $_POST["select-status"];
         $datapedido = $_POST["datapedido"];
         $cliente = $_POST["select-cliente"];
         $tipo = $_POST["select-tipo"];

         $sql = "DELETE FROM pedidos WHERE NRO_PEDIDO";
                  mysqli_query($connection, $sql);
         }

         //Consulta produtos
         $produtos = mysqli_query($connection, "SELECT DESCRICAO FROM produtos WHERE MOSTRA_WEB = '1' ORDER BY DESCRICAO");

         //Consulta valor unitário
         //$vUni = mysqli_query($connection, "SELECT P_VENDA FROM produtos");
         //$resUni = mysqli_fetch_assoc($connection, $vUni);

			
      ?>
   </head>
   <body>

      <div class="container">
        <form class="form-horizontal" action="cadastrarPedido.php" method="post">
            <legend><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Cadastro de Pedidos</legend>
               <?php if(isset($_POST["Alterar"]) || isset($_POST["Inserir"])){ echo $mensagem;} else{}?>
            <div class="form-group">
               <legend>Dados Pedido</legend>
               <label class="control-label col-sm-2">ID</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control" name="id_Pedido" value=""/>
               </div>
            </div>
       
            <div class="form-group">
               <label class="control-label col-sm-2">Vendedor</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control" name="idusuario" value="<?php echo "$login_cookie"?> "/>
               </div>
            </div>
            
            <div class="form-group">
               <label class="control-label col-sm-2">Status</label>
               <div class="col-sm-10">
               		<select class=form-control name="select-status">
               			<option value="status-1">Pendente</option>
               			<option value="status-2">Processado</option>
               		</select>
               </div>
            </div>
			   
            <div class="form-group">
               <label class="control-label col-sm-2">Data</label>
			   <div class="col-sm-10">
            	   <input class="form-control" type="date" placeholder="__/__/__" name="datapedido"/>
			   </div>
   			</div>

            <!--Aqui precisa um if-->
            <legend>Dados do Cliente</legend>
   			<div class="form-group">
                  <label class="control-label col-sm-2">Cliente</label>
                  <div class="col-sm-10">
                  	<select class="form-control" name="select-cliente">
   					   <option>Selecione..</option>
                        <?php while($client = mysqli_fetch_assoc($clientes)) { ?>
   						 	<option value=""><?php echo $client['CODIGO']." - ".$client['NOME'] ?></option>
   						   <?php } ?>
   			      	</select>
   	         </div>
            </div>

            <!-- Aqui precisa um if-->
            <div class="form-group">
               <label class="control-label col-sm-2">Tipo</label>
               <div class="col-sm-10">
               		<select class="form-control" name="select-tipo">
               			<option value="tipo-a">A</option>
               			<option value="tipo-b">B</option>
               		</select>
               </div>
            </div>

            <div class="form-group">
               <div class="col-sm-offset-2 col-sm-10">
                  <button class="btn btn-success" name="incluir" type="submit"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span> incluir</button>
                  <button class="btn btn-success" name="excluir" type="submit"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> excluir</button>
               </div>
            </div>

            <!--<legend>Itens Pedido</legend>
            <div class="form-group">
               <label class="control-label col-sm-2">Produto</label>
               <div class="col-sm-10">
               		<select class="form-control" name="select-produto">
                   <option>Selecione..</option>
                    <?php while($prod = mysqli_fetch_assoc($produtos)) { ?>
                     <option value=""><?php echo $prod['DESCRICAO'] ?></option>
                   <?php } ?>
					</select>
               </div>
            </div>

            <div class="form-group">
               <label class="control-label col-sm-2">Qtn</label>
               <div class="col-sm-10">
                  <input type="text" name="status" class="form-control" value=""/>
               </div>
            </div>

            <div class="form-group">
               <label class="control-label col-sm-2">V.Unit</label>
               <div class="col-sm-10">
                  <input type="text" name="vUnit" disabled class="form-control" value="<?php echo $resUni['P_VENDA']?>"/>
               </div>
            </div>

            <div class="form-group">
               <label class="control-label col-sm-2">Total</label>
               <div class="col-sm-10">
                  <input type="text" name="vTotal" disabled class="form-control" value=""/>
               </div>
            </div>

            <div class="panel panel-primary">-->
            <!-- Default panel contents -->
            <!--<div class="panel-heading">PEDIDOS</div>
            <div class="table-responsive">
               <table class="table table-bordered">
                  <caption></caption>
                     <thead>
                        <tbody>
                           <tr>
                              <th>Código</th>
                              <th>Produto</th>
                              <th>Qtn</th>
                              <th>V.Unit</th>
                              <th>Total</th>
                              <th> </th>
                           </tr>
                     </thead>

            <?php
      
           // while($ref = mysqli_fetch_assoc($produtos)) {
         
            ?>

            <tr>
               <td><?php echo $ref ["CODIGO"]?></td>
               <td><?php echo $ref ["DESCRICAO"]?> </td>
               <td><?php echo $ref ["P_VENDA"]?></td>
               <td><?php echo $ref ["TOTAL"]?></td>
               <td> </td>
         
               <td>
                  <a data-toggle='tooltip' data-placement='top' class="btn btn-danger" title="Excluir" href="listarPedido.php?id=<?php echo $ref["id"]?>" ><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
                  <a data-toggle='tooltip' data-placement='top' class="btn btn-primary" title="Alterar" href="cadastrarPedido.php?id=<?php echo $ref["id"]?>"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
               </td>
            </tr>
            
            <?php 
            // }
            ?>
  
            </tbody>
            </table>
            </div></div>

            <div class="form-group">
               <div class="col-sm-offset-2 col-sm-10">
                  <button class="btn btn-success" name="salvar" type="submit"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> salvar</button>
                  <button class="btn btn-success" name="excluir" type="submit"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> excluir</button>
               </div>
            </div>-->

        </form>
      </div>

   	</body>
</html>