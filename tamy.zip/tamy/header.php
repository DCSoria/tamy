<!DOCTYPE html>
<html>
<head>
  <?php
    $connection = mysqli_connect("ncsistemas.myscriptcase.com", "ncsistem_1", "ncs1st3m4s!@", "ncsistem_tamy") or die ("Não foi possível conectar com o Banco.");
    mysqli_set_charset($connection, "utf8");
		$login_cookie = $_COOKIE['login'];
	
	if(isset($login_cookie)){

    }
	else{
		//echo"Bem-Vindo, convidado <br>";
			header("Location:login.php");
	}
	
  if(isset($_POST["Sair"])){
    setcookie("login");
    header("Location:login.php");
	}
	?>
  
  <meta http-equiv="Content-Type" Content="text/html" charset="UTF-8">
	<link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/estilo.css" rel="stylesheet">
  <link href="css/navbar-fixed-top.css" rel="stylesheet">

	<title>Sistema de Pedidos Externos</title>
	
</head>
  <body>
  
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <img width="100px" class="img-lg" src="../tamy\imagens/logo.png">
        </div>
      
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="home.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Principal</a></li>
            <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-user" aria-hidden="true"></span> Usuários<span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="cadastrarUsuario.php">Cadastrar Usuário</a></li>
		          <li role="separator" class="divider"></li>
              <li><a href="listarUsuarios.php">Pesquisar Usuários</a></li> 
            </ul>

		        <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> Pedidos<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="cadastrarPedido.php">Novo Pedido</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="listarPedido.php">Consultar Pedidos</a></li>
              </ul>
            </li>
			
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> Relatórios<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="">Pedidos Processados</a></li>
              </ul>
            </li>
          </ul>
          
          <ul class="nav navbar-nav navbar-right" style="margin-top:8px;">
            <li style="margin-left:8px; margin-top:-8px;">
              <a href="" style="color:#3CB371"><span class="glyphicon glyphicon-user" aria-hidden="true"></span> <?php echo strtoupper($login_cookie); ?></a>
            </li>
            <li style="margin-left:8px;">
              <form class="form-horizontal" action="header.php" method="post"><button data-toggle='tooltip' data-placement='bottom' title="Sair" class="btn btn-danger" type="submit" name="Sair"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button></form>
            </li>
          </ul>
		  
        </div><!--/.nav-collapse -->
      </div>
    </nav>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
	$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
  </script>

  </body>
</html>