<html>
   <head>
      <?php
        INCLUDE "header.php";
		
		if ( isset($_POST['name']) && isset($_POST['login']) && isset($_POST['pswd']) && isset($_POST['email']) && isset($_POST['id']) )
		{
			$name = $_POST['name'];
			$login = $_POST['login'];
			$pswd = $_POST['pswd'];
			$email = $_POST['email'];
			$id_vendedor = $_POST['id'];

			//Consulta no banco de dados e inserção na tabela
			if(isset($_POST["Inserir"]))
			{
				$resultado = mysqli_query($connection, "SELECT * FROM sec_users WHERE login = '$login' or email = '$email'");
				if (mysqli_num_rows($resultado) > 0) 
				{
					$alerta = "Login ou E-mail já existe";
					$mensagem = "<div class=\"alert alert-warning\" role=\"alert\">".$alerta."</div>";	 
				}
				else 
				{
					$sqlInserir = "INSERT INTO sec_users (login, pswd, name, email, id_vendedor) VALUES ('$login','$pswd', '$name', '$email', '$id_vendedor')";
					mysqli_query($connection, $sqlInserir);
					
					//Exibe uma mensagem para o usuário
					$sucesso = "<strong>Usuário cadastrado com sucesso</strong>";
					$mensagem = "<div class=\"alert alert-success\" role=\"alert\">".$sucesso."</div>";
					//Refresh da mensagem
					echo "<meta HTTP-EQUIV='refresh' CONTENT='2;URL=cadastrarUsuario.php'>";
				}
		
			}

			//Consulta no banco de dados e alteração na tabela
			if(isset($_POST["Alterar"]))
			{
				$id_vendedor = isset($_POST["id"]);
				$name = isset($_POST["name"]);
				$login = isset($_POST["login"]);
				$pswd = isset($_POST["pswd"]);
				$email = isset($_POST["email"]);
         
				$sqlAlterar = "UPDATE sec_users SET id_vendedor = '$id_vendedor',
				name = '$name', 
				login = '$login', 
				pswd = '$pswd',
				email = '$email'
				WHERE login = '$login";
         
				mysqli_query($connection, $sqlAlterar);
				
				//Exibe uma mensagem para o usuário
				$sucesso = "<strong>Usuário alterado com sucesso</strong>";
				$mensagem = "<div class=\"alert alert-success\" role=\"alert\">".$sucesso."</div>";
				//Refresh da mensagem
				echo "<meta HTTP-EQUIV='refresh' CONTENT='2;URL=cadastrarUsuario.php'>";
				}
			}
		
			//Aqui recebe os dados para alteração da página listarUsuarios.php
	         
	         if(isset($_GET["login"])) {
				$botao = "<button class='btn btn-success' name='Alterar' type='submit'><span class='glyphicon glyphicon-edit' aria-hidden='true'></span> alterar</button>";
				$login = $_GET["login"];
				$consulta = "SELECT * FROM sec_users WHERE login = {$login} ";
				$resultado = mysqli_query($connection, $consulta);
				$linha = mysqli_fetch_assoc($resultado);
			 } else {
				 $linha = 0; 
			 }

        ?>
   </head>
   <body>
   <fieldset>
      <div class="container">
  	  
               <form class="form-horizontal" action="cadastrarUsuario.php" method="post" name="f1">
                  <legend><span class="glyphicon glyphicon-user" aria-hidden="true"></span> Cadastro de Usuário</legend>
                 	<?php if(isset($_POST["Alterar"]) || isset($_POST["Inserir"])){ echo $mensagem;} else{}?>
                <div id="msgemail"></div>
                           <div class="form-group">
                            	<label class="control-label col-sm-2">ID Vendedor</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" name="id" value="<?php echo $linha["id_vendedor"]?>"/>
								</div>
                           </div>
							
                           <div class="form-group">
                              <label class="control-label col-sm-2">Nome</label>
							  <div class="col-sm-10">
                              <input type="text" class="form-control" name="name" value="<?php echo $linha["name"]?> "/></div>
                           </div>
						   
						   <div class="form-group">
                              <label class="control-label col-sm-2">E-mail</label>
							  <div class="col-sm-10">
                              <input type="email" onblur="validacaoEmail(f1.email)" id="email" class="form-control" name="email" value="<?php echo $linha["email"]?> "/></div>
                           </div>
             
                           <div class="form-group">
                              <label class="control-label col-sm-2">Login</label>
							  <div class="col-sm-10">
                              <input type="text" class="form-control" placeholder="login" name="login" value="<?php echo $linha["login"]?> "/></div>
                           </div>
                     
                           <div class="form-group">
                              <label class="control-label col-sm-2">Senha</label>
							  <div class="col-sm-10">
                              <input type="password" class="form-control" placeholder="*****" name="pswd" value="<?php echo $linha["pswd"]?> "/></div>
                           </div>
                     <div class="form-group">
					   <div class="col-sm-offset-2 col-sm-10">
                     <button class="btn btn-success" name="Inserir" type="submit"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Salvar</button>
                     
					 <?php if(isset($_GET["login"])){ echo $botao;} else{}?>
                  </div>
                  </div>
               </form>
			   
            </div>
			</fieldset>
			<script language="Javascript">
function validacaoEmail(field) {
usuario = field.value.substring(0, field.value.indexOf("@"));
dominio = field.value.substring(field.value.indexOf("@")+ 1, field.value.length);

if ((usuario.length >=1) &&
    (dominio.length >=3) && 
    (usuario.search("@")==-1) && 
    (dominio.search("@")==-1) &&
    (usuario.search(" ")==-1) && 
    (dominio.search(" ")==-1) &&
    (dominio.search(".")!=-1) &&      
    (dominio.indexOf(".") >=1)&& 
    (dominio.lastIndexOf(".") < dominio.length - 1)) {
document.getElementById("msgemail").innerHTML="";
//alert("E-mail valido");
var elemento = document.querySelector("#email");
elemento.style.borderColor = "";

}
else{
document.getElementById("msgemail").innerHTML="<div class='alert alert-danger' role='alert'><strong>Atenção!</strong> Email Inválido. </div>";
//alert("E-mail invalido");
document.f1.email.focus();
var elemento = document.querySelector("#email");
elemento.style.borderColor = "#D93600";
}
}
</script>
   </body>
</html>