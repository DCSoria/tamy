<html>
<head>

		<?php
        	INCLUDE 'header.php';
		
			$complemento = "";
			if(isset($_POST["Pesquisar"])) {
				$filtro = $_POST["filtro"];
				$complemento = "WHERE u.NRO_PEDIDO LIKE '%{$filtro}%'";
			}		
			$sql = "SELECT u.NRO_PEDIDO, u.CLIENTE, u.DATA, u.F_PGTO, u.TOTAL_LIQUIDO, u.STATUS FROM pedidos".$complemento;
		
	 		//Executa no banco, retornando os registros da tabela
			$lista = mysqli_query($connection, $sql);
		
			//Exclui da Lista
			if(isset($_GET["id"])) {
				$id = $_GET["id"];
				$sqlSelect = "SELECT u.NRO_PEDIDO, u.CLIENTE, u.DATA, u.F_PGTO, u.TOTAL_LIQUIDO, u.STATUS FROM pedidos WHERE id_Pedido = '$id'";
				$resultSet = mysqli_query($connection, $sqlSelect);
				$result = mysqli_fetch_array($resultSet);
				$id_Pedido = $result["id_Pedido"];

			if($id_Pedido <> "") {
				
				$erro = "<strong>Importante:</strong> Esse livro não pode ser excluído pois possuí vinculos de empréstimos.";
				$mensagem = "<div class=\"alert alert-danger\" role=\"alert\">".$erro."</div>";
				}
			else {
				$id = $_GET["id"];
				$sqlDelete = "DELETE FROM livro WHERE id=$id";
				mysqli_query($connection, $sqlDelete);
				$sucesso = "<strong>Pedido excluído com sucesso.</strong>";
				$mensagem = "<div class=\"alert alert-success\" role=\"alert\">".$sucesso."</div>";
				echo "<meta HTTP-EQUIV='refresh' CONTENT='1;URL=listarPedido.php'>";
				}
			}
	 	?>
      
	
		<title>Pedidos</title>
</head>
	<body>
		<div class="container"> 
			<legend><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> Pesquisa Rápida de Pedidos</legend>
	 		<form class="form-search" action="listarPedido.php" method="post">
		<div class="row">
 
  		<div class="col-lg-6">
  			<div class="form-group">
    			<div class="input-group">
      				<input type="text" class="form-control" placeholder="Informe o nome do cliente" type="text" name="filtro">
      				<span class="input-group-btn">
        				<button class="btn btn-default" type="submit" name="Pesquisar">Buscar</button>
      				</span>
    			</div><!-- /input-group -->
  			</div><!-- /.col-lg-6 -->
		</div>
		</div>
		</form>
	
		<?php if(isset($_GET["id"])){ echo $mensagem;} else{}?>
		<div class="panel panel-primary">
  			<!-- Default panel contents -->
  			<div class="panel-heading">LISTA DE PEDIDOS</div>
				<div class="table-responsive">
  					<table class="table table-bordered">
    					<caption></caption>
    						<thead>
								<tbody>
    								<tr>
    									<th>Código</th>
    									<th>Cliente</th>
										<th>Data</th>
										<th>Forma Pgto</th>
										<th>Total</th>
										<th>Status</th>
										<th> </th>
    								</tr>
    						</thead>
  		<?php
   
   		while($id_Pedido = mysqli_fetch_assoc($lista)) {
   
   		?>
   
    	<tr>
    		<td><?php echo $id_Pedido ["NRO_PEDIDO"]?></td>
    		<td><?php echo $id_Pedido ["CLIENTE"]?></td>
			<td><?php echo $id_Pedido ["DATA"]?></td>
			<td><?php echo $id_Pedido ["F_PGTO"]?></td>
			<td><?php echo $id_Pedido ["TOTAL_LIQUIDO"]?></td>
			<td><?php echo $id_Pedido ["STATUS"]?></td>
   
			<td>
				<a data-toggle='tooltip' data-placement='top' class="btn btn-danger" title="Excluir" href="listarPedido.php?id=<?php echo $livro["id"]?>" ><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
				<a data-toggle='tooltip' data-placement='top' class="btn btn-primary" title="Alterar" href="cadastrarPedido.php?id=<?php echo $livro["id"]?>"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
			</td>
		</tr>
  		<?php 
   		}
    	?>
  
    </tbody>
    </table></div></div></div>
	</body>
</html>