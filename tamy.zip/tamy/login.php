<?php 
  //Cria a conexao msqli_connect
$connection = mysqli_connect("ncsistemas.myscriptcase.com", "ncsistem_1", "ncs1st3m4s!@", "ncsistem_tamy") or die ("Falha ao realizar a conexão.");

  //Ajusta o charset de comunicação entre a aplicação e o banco de dados
mysqli_set_charset($connection, "utf8");

if (isset($_POST["entrar"])) {

$login = $_POST['login'];
$senha = $_POST['pswd'];

$verifica = mysqli_query($connection, "SELECT * FROM sec_users WHERE login like '%$login%' AND pswd like '%$pswd%'") or die ("erro ao selecionar");

	if (mysqli_num_rows($verifica)<=0){
		echo"<script language='javascript' type='text/javascript'>alert('Login e/ou senha incorretos');window.location.href='login.php';</script>";
		die();
}
  else{
		if($login == 'login' && id_vendedor == '1')
		{
		  setcookie("login",$login);
		  header("Location:home.php");
		}
		else{
			setcookie("login",$login);
		  header("Location:home.php");
		}
	}
}
			 
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">

    <title>Sistemas de Pedidos Externos</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/estilo.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="signin.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body class="blogin">

    <div class="img">
      <img class="img-logo" src="../tamy\imagens/logo.png">
    </div>
  
    <div class="container">

      <form class="form-signin" method="POST" action="login.php">
        <h2 class="form-signin-heading slogan">Sistema de Pedidos Externos</h2>
        <label for="inputEmail" class="sr-only" >Login</label>
        <input type="login" id="login" class="form-control form-ls" placeholder="Usuário" name="login" style="margin-bottom: 30px" required autofocus>
        <label for="inputPassword" class="sr-only">Senha</label>
        <input type="password" id="inputPassword" class="form-control form-ls" placeholder="Senha"  style="margin-bottom: 30px" name="senha" id="senha" required>
        <button class="btn btn-lg btn-primary btn-block btn-entrar" type="submit" value="entrar" name="entrar" id="entrar">Entrar</button>
      </form>

    </div> <!-- /container -->


    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>

  </body>
</html>