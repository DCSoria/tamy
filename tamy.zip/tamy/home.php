<html>
<head>

		<?php
      INCLUDE 'header.php';
		?>
    
</head>
  <body>


    <div class="container theme-showcase" role="main">

      <!-- Main jumbotron for a primary marketing message or call to action -->
      <div class="jumbotron">
        <h1>Bem vindo, <?php echo strtoupper($login_cookie) ?></h1>
        <h2>Tamy Sistemas de Pedidos Externos.</h2>
      </div>

    </div>

  </body>
</html>