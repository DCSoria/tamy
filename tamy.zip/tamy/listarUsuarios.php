<html>
<head>

	<?php
	    INCLUDE 'header.php';
		
		//Lista e Filtra busca
		$complemento = "";
		if(isset($_POST["filtro"])) {
			$filtro = $_POST["filtro"];
			$complemento = " WHERE u.name LIKE '%$filtro%' ";
		}

		//Consulta id_vendedor, name, login, email conforme filtro
		$sql = "SELECT u.id_vendedor, u.name, u.login, u.email FROM sec_users u".$complemento;
		
		//executa no banco, retornando os registros da tabela
		$lista = mysqli_query($connection, $sql);
		
		//Exclui usuário do banco
		if(isset($_GET["login"])) {
			$login = $_GET["login"];

			$exclusao = "DELETE FROM sec_users ";
			$exclusao .= "WHERE login = {$_GET['login']} ";
			$con_Exclusao = mysqli_query($connection, $exclusao);

			$sucesso = "<strong>Usuário excluído com sucesso</strong>";
			$mensagem = "<div class=\"alert alert-success\" role=\"alert\">".$sucesso."</div>";
			//Refresh da mensagem
			echo "<meta HTTP-EQUIV='refresh' CONTENT='2;URL=listarUsuarios.php'>";

		}

	?>
</head>
	<body>
		<div class="container"> 
			<legend><span class="glyphicon glyphicon-user" aria-hidden="true"></span> Pesquisar usuários</legend>
			<form class="form-search" action="listarUsuarios.php" method="post">
				<div class="row">
 					<div class="col-lg-6">
  						<div class="form-group">
    						<div class="input-group">
      							<input type="text" class="form-control" placeholder="Informe o nome do usuário" type="text" name="filtro">
      							<span class="input-group-btn">
        							<button class="btn btn-default" type="submit" value="pesquisar">Buscar</button>
      							</span>
    						</div><!-- /input-group -->
  						</div><!-- /.col-lg-6 -->
					</div>
				</div>
			</form>
	
		<?php if(isset($_GET["login"])){ echo $mensagem;} else{}?>

		<div class="panel panel-primary">
  		<!-- Default panel contents -->
  			<div class="panel-heading">LISTA DE USUÁRIOS</div>
				<div class="table-responsive">
  					<table class="table table-bordered">
  						<caption></caption>
  							<thead>
  								<tbody>
  									<tr>
    									<th>ID</th>
   										<th>Nome</th>
										<th>Login</th>
										<th>Email</th>
										<th> </th>
    								</tr>
    						</thead>
  		
    	<!--Exibe os dados encontrados na consulta-->
  		<?php
  		
  		while($id_user = mysqli_fetch_assoc($lista)) {
   		
   		?>
   
       	<tr>
    		<td><?php echo $id_user ["id_vendedor"]?></td>
    		<td><?php echo $id_user ["name"]?></td>
			<td><?php echo $id_user ["login"]?></td>
			<td><?php echo $id_user ["email"]?></td>
	   		<td>
				<a data-toggle='tooltip' data-placement='top' class="btn btn-danger" title="Excluir" href="listarUsuarios.php?login=<?php echo $id_user["login"]?>" ><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
				<a data-toggle='tooltip' data-placement='top' class="btn btn-primary" title="Alterar" href="cadastrarUsuario.php?login=<?php echo $id_user["login"]?>"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
			</td>
		</tr>
  		
  		<?php 
    	}
 	   	?>
  
    </tbody>
    </table>
	</div></div></div>
	</body>
</html>