<html>
   <head>
      <?php
         INCLUDE "header.php";
		 if (isset($_POST['nomelivro']) && isset($_POST['quantidade']))
		{
         $data = $_POST['data'];
         $quantidadedisponivel = $quantidade;
         
         if(isset($_POST["Inserir"]))
         {
         
         $sql = "INSERT INTO pedidos (NRO_PEDIDO, VENDEDOR, DATA, STATUS) VALUES ('$data')";
         mysqli_query($connection, $sql);
		$sucesso = "<strong>Pedido Salvo</strong>";
		$mensagem = "<div class=\"alert alert-success\" role=\"alert\">".$sucesso."</div>";	 
         }
	}
         if(isset($_POST["Alterar"]))
         {	
			
         $id = isset($_POST["id"]);	
		$sqlSelect = "select * from livro where id = '$id'";	
		$row = mysqli_fetch_row($connection, $sqlSelect);
		$quantidadeemprestado = $row[4];
		$quantidadereservado = $row[5];
         $nomelivro = isset($_POST["nomelivro"]);
         $quantidade = isset($_POST["quantidade"]);
		 $quantidadedisponivel = $quantidade - ($quantidadeemprestado + $quantidadereservado);
         
         $sql = "UPDATE livro SET nomelivro = '$nomelivro', 
           quantidade = '$quantidade',
           quantidadedisponivel = '$quantidadedisponivel';
           WHERE id = '$id'";
         
         mysqli_query($connection, $sql);
		 $sucesso = "<strong>Pedido alterado com sucesso</strong>";
				$mensagem = "<div class=\"alert alert-success\" role=\"alert\">".$sucesso."</div>";
         
         }	
         //aqui recebe os dados para alteração
         
         if(isset($_GET["id"]))
         {
			 $botao = "<button class=\"btn btn-success\" name=\"Alterar\" type=\"submit\"><span class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></span> alterar</button>";
			$id = $_GET["id"];
			$sql = "select * from livro where id=$id";
			$resultado = mysqli_query($connection,$sql);
			$linha = mysqli_fetch_assoc($resultado);
			
         }
		 else
		 {
			 $linha = 0; 
		 }

         
         ?>
   </head>
   <body>
      <div class="container">
         <form class="form-horizontal" action="cadastrarLivro.php" method="post">
            <legend><span class="glyphicon glyphicon-th-list" aria-hidden="true"></span> Cadastro de Pedidos</legend>
		    <?php if(isset($_POST["Alterar"]) || isset($_POST["Inserir"])){ echo $mensagem;} else{}?>
            
            <div class="form-group">
               <label class="control-label col-sm-2">Id</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control" disabled name="id" value="<?php echo $linha["id"]?> "/>
               </div>
            </div>
            <div class="form-group">
               <label class="control-label col-sm-2">Vendedor</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control" disable name="login" value="<?php echo $linha["login"]?> "/>
               </div>
            </div>
            <div class="form-group">
               <label class="control-label col-sm-2">Data</label>
               <div class="col-sm-10">
                  <input type="date" class="form-control" name="Data" value="<?php echo $linha["quantidade"]?> "></input>
               </div>
            </div>
            <div class="form-group">
               <label class="control-label col-sm-2">Status</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control" placeholder="quantidade" name="quantidade" value="<?php echo $linha["quantidade"]?> "></input>
               </div>
            </div>
            <div class="form-group">
               <div class="col-sm-offset-2 col-sm-10">
                  <button class="btn btn-success" name="Inserir" type="submit"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span> Salvar</button>
                 	 <?php if(isset($_GET["id"])){ echo $botao;} else{}?>
               </div>
            </div>
         </form>
      </div>
   </body>
</html>